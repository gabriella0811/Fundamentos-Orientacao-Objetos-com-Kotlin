package one.digitalinnovation.digionebank.testes

import one.digitalinnovation.digionebank.Logavel

class TesteAutenticacao {
    fun autentica(logavel: Logavel) = println(logavel.login())
}