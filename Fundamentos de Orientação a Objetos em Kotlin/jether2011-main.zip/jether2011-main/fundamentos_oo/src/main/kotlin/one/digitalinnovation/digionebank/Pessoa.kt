package one.digitalinnovation.digionebank

abstract class Pessoa(
    val nome: String,
    val cpf: String
)

